using System;
using System.Threading.Tasks;
using System.Collections.Generic;
using System.IO;
using System.Net;
using System.Text;
using Newtonsoft.Json;

using Amazon.Lambda.Core;
using Amazon.KinesisAnalytics;
using Amazon.KinesisAnalytics.Model;

// Assembly attribute to enable the Lambda function's JSON input to be converted into a .NET class.
[assembly: LambdaSerializer(typeof(Amazon.Lambda.Serialization.Json.JsonSerializer))]

namespace KinesisAnalyticsHelper
{
    public class StarterApp
    {
        public class CFNCustomResouceEventData
        {
            public string RequestType { get; set; }
            public string ServiceToken { get; set; }
            public string ResponseURL { get; set; }
            public string StackId { get; set; }
            public string RequestId { get; set; }
            public string LogicalResourceId { get; set; }
            public string ResourceType { get; set; }
            public CFNCustomData ResourceProperties { get; set; }
        }
        public class CFNCustomData
        {
            public string ServiceToken { get; set; }
            public string ApplicationName { get; set; }
            public string CustomResourceAction { get; set; }
        }

        public class CFNCustomResourceResponse
        {
            public string Status { get; set; }
            public string Reason { get; set; }
            public string PhysicalResourceId { get; set; }
            public string StackId { get; set; }
            public string RequestId { get; set; }
            public string LogicalResourceId { get; set; }
            public bool NoEcho { get; set; }
            public CFNCustomResourceResponseData Data { get; set; }
        }

        public class CFNCustomResourceResponseData
        {
            public string Message { get; set; }
        }

        static CFNCustomResourceResponse UploadResponse(string responseStatus, string responseData, CFNCustomResouceEventData kadata, ILambdaContext context)
        {
            CFNCustomResourceResponseData statusMessage = new CFNCustomResourceResponseData();
            statusMessage.Message = responseData;

            CFNCustomResourceResponse cfnResponse = new CFNCustomResourceResponse();
            cfnResponse.Status = responseStatus;
            cfnResponse.Reason = responseData;
            cfnResponse.PhysicalResourceId = context.LogStreamName;
            cfnResponse.StackId = kadata.StackId;
            cfnResponse.RequestId = kadata.RequestId;
            cfnResponse.LogicalResourceId = kadata.LogicalResourceId;
            cfnResponse.NoEcho = false;
            cfnResponse.Data = statusMessage;

            string s3SignedURL = kadata.ResponseURL;
            HttpWebRequest httpRequest = WebRequest.Create(s3SignedURL) as HttpWebRequest;
            httpRequest.Method = "PUT";

            string dataAsJson = JsonConvert.SerializeObject(cfnResponse);
            byte[] dataAsBytes = Encoding.UTF8.GetBytes(dataAsJson);

            using (Stream dataStream = httpRequest.GetRequestStream())
            {
                byte[] buffer = new byte[dataAsBytes.Length];
                using (MemoryStream memoryStream = new MemoryStream(dataAsBytes))
                {
                    int bytesRead = 0;
                    while ((bytesRead = memoryStream.Read(buffer, 0, buffer.Length)) > 0)
                    {
                        dataStream.Write(buffer, 0, bytesRead);
                    }
                }
            }
            HttpWebResponse response = httpRequest.GetResponse() as HttpWebResponse;

            return cfnResponse;
        }

        public async Task<CFNCustomResourceResponse> KinesisAnalyticsAppStart(CFNCustomResouceEventData kadata, ILambdaContext context)
        {
            Console.WriteLine(string.Format("Begin Processing ..."));
            string ApplicationName = kadata.ResourceProperties.ApplicationName;
            StartApplicationResponse saResponse = null;
            string responseStatus = string.Empty;
            string responseMsg = string.Empty;

            try
            {
                /* 
                * Call DescribeApplication to get the Application ID. You need this to call the StartApplication
                */
                DescribeApplicationRequest appRequest = new DescribeApplicationRequest();
                appRequest.ApplicationName = ApplicationName;
                Console.WriteLine(string.Format(string.Format("Analytics Application Name = {0}", ApplicationName)));
                AmazonKinesisAnalyticsClient kaClient = new AmazonKinesisAnalyticsClient();
                DescribeApplicationResponse appResponse = await kaClient.DescribeApplicationAsync(appRequest);

                // Now get the Application InputID from the DescribeApplicationResponse.InputDescriptions
                string appID = string.Empty;

                foreach (InputDescription inputDes in appResponse.ApplicationDetail.InputDescriptions)
                {
                    appID = inputDes.InputId;
                }
                Console.WriteLine(string.Format(string.Format("Analytics Application ID = {0}", appID)));

                /*
                * Create the StartApplication Request and populate - ApplicationName, ApplicationID and InputStartingPosition
                */
                StartApplicationRequest saRequest = new StartApplicationRequest();

                // Creaate the List<InputConfiguration>
                List<InputConfiguration> listInputConfig = new List<InputConfiguration>();
                InputConfiguration reqInputConfig = new InputConfiguration();

                InputStartingPositionConfiguration inputStartingPosition = new InputStartingPositionConfiguration();
                inputStartingPosition.InputStartingPosition = "NOW";
                reqInputConfig.InputStartingPositionConfiguration = inputStartingPosition;
                reqInputConfig.Id = appID;
                listInputConfig.Add(reqInputConfig);

                saRequest.ApplicationName = ApplicationName;
                saRequest.InputConfigurations = listInputConfig;

                Console.WriteLine(string.Format("Starting Application ..."));
                saResponse = await kaClient.StartApplicationAsync(saRequest);

                responseStatus = "SUCCESS";

            }
            catch (Exception ex)
            {
                responseMsg = string.Format("Failed to start Kinesis Analytics Application = {0}; Error Reported = {1}", ApplicationName, ex.Message);
                responseStatus = "FAILED";
               
            }

            //finally upload the response to S3 using S3 Signed URL
            Console.WriteLine(string.Format(string.Format("Begin uploading Response Date to CFN S3 Bucket using SignedURL")));
            CFNCustomResourceResponse cfnResponse = UploadResponse(responseStatus, responseMsg, kadata, context);
            Console.WriteLine(string.Format(string.Format("Completed uploading Response Date to CFN S3 Bucket using SignedURL")));

            return cfnResponse;
        }
     }
}